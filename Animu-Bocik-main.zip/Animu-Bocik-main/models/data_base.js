const mongoose = require('mongoose');
const  baza = new mongoose.Schema({
    userId: {
        type: String,
        required: true,
    },
    karta: {
        type: Array,
        default: [],
    },
});

const iks_de = mongoose.model('iks_de', baza);
module.exports = iks_de;