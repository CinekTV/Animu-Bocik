const mongoose = require('mongoose');
const user_model = new mongoose.Schema({
    userId: {
        type: String,
        required: true,
    },
    deck: {
        type: Array,
        default: [],
    },
    commandCooldown: {
        type: Date,
        default: 0,
        required: true,
    },
    image:{
        data: Buffer,
        contentType: String,
    }
});

const User = mongoose.model('User', user_model);
module.exports = User;
